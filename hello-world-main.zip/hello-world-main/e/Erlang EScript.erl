#!/usr/bin/env escript

main(_) ->
    io:format("Hello World~n").
