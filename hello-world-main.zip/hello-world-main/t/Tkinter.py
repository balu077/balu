import tkinter as tk
root = tk.Tk()
greeting = tk.Label(text="Hello World")
greeting.pack()
root.mainloop()
