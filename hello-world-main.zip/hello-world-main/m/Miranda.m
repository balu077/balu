main :: [sys_message]
main = [Stdout "Hello World"]
