HORA DO SHOW // main code block
    CE QUER VER ESSA PORRA? ("Hello World\n"); // print "Hello World""
    BORA CUMPADE 0; // end function
BIRL