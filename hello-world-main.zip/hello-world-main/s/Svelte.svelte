<script>
  let message = 'Hello World';
</script>

<p>{ message }</p>