#!/usr/bin/env ruby
print "Hello World"
