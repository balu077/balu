class HelloWorld < app
  print "Hello World"
  end
end
