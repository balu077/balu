$scope.$log = $log;
$scope.message = "Hello World";
