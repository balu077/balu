#!/usr/bin/env zx
console.log("Hello World")
